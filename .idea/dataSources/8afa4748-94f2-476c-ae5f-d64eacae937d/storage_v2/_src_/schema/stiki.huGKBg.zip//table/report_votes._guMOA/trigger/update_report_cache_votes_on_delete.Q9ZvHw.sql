create definer = root@localhost trigger update_report_cache_votes_on_delete
    after delete
    on report_votes
    for each row
BEGIN
    SET @positiveCount = 0;
    SET @negativeCount = 0;
    SELECT COUNT(*) INTO @positiveCount FROM report_votes WHERE type = 'positive' AND report_id = OLD.report_id;
    SELECT COUNT(*) INTO @negativeCount FROM report_votes WHERE type = 'negative' AND report_id = OLD.report_id;
    UPDATE reports SET cache_votes = @positiveCount - @negativeCount WHERE reports.id = OLD.report_id;
end;

